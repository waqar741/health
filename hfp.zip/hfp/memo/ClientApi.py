import requests
from django.conf import settings

API = settings.API_BASE_URL

def get_access_from_session(request):
    return request.session.get('access')

def api_headers(request):
    access = get_access_from_session(request)
    if not access:
        return {}
    return {'Authorization': f'Bearer {access}'}

def api_get(request, path, params=None):
    return requests.get(f"{API}/{path.lstrip('/')}", headers=api_headers(request), params=params)

def api_post(request, path, data=None, files=None):
    return requests.post(f"{API}/{path.lstrip('/')}", headers=api_headers(request), data=data, files=files)

def api_patch(request, path, data=None, files=None):
    return requests.patch(f"{API}/{path.lstrip('/')}", headers=api_headers(request), data=data, files=files)

def api_delete(request, path):
    return requests.delete(f"{API}/{path.lstrip('/')}", headers=api_headers(request))
